function confirm_alert(node) {
   return confirm("Нажмите Да, если хотите удалить");
}