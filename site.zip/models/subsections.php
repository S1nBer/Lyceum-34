<?php
function sections_all(){

}

function get_section($id){

}


function edit_section($id, $title, $date, $content){
   
}

function delete_section($id){
   
}

function new_section($title, $date, $content){
   
}
?>